Polymer({
	properties: {
		transition_speed: {
			type: Number,
			observer: 'transition_speedChanged'
		},
		the_caption: {
			type: String,
			notify: true
		},
		category: {
			type: String,
			observer: 'categoryChanged'
		},
		slide_style: {
			type: String,
			value: 'nine-ways-centered'
		}
	},
	behaviors: [
		StoryBlocksBehaviors
	],
	_retry_count: 0,
	_retry_max: 20,
	_retry_interval: 150,
	_retry: function() {
		var dot_count,
			slide_count;

		if (!this.swiper || this._retry_count >= this._retry_max) {
			return;
		}

		slide_count = this.swiper.slides.length;
		dot_count = this.querySelectorAll('.swiper-pagination-bullet').length;

		if (dot_count < slide_count) {
			this.rebootSwiper(this.swiper);
			this._retry_count++;
			setTimeout(this._retry.bind(this), this._retry_interval);
		}
	},

	init: function() {
		if (!this._swiperReady) {
			this._deferred = true;
			return;
		}

		if (this.swiper) {
			$(this).off('alignmentChanged.swiper rowDeleted.swiper rowAdded.swiper imageLoaded.swiper change.swiper chapterChange.swiper');
			$(window).off('resize.swiper');
			this.swiper.params.onDestroy = this.buildSwiper.bind(this);
			this.swiper.destroy();
		} else {
			this.buildSwiper();
		}

	},

	initSwiper: function(swiper) {
		$(this).on('alignmentChanged.swiper', function() {
			this.rebootSwiper(swiper);
		}.bind(this));

		$(this).on('rowAdded.swiper', function(e) {
			var row = e.originalEvent.detail;
			if (row && this.editable()) {
				row.querySelector('p').addEventListener('mousedown', function(evt) {
					evt.stopPropagation();
				}, true);
			}

			this.rebootSwiper(swiper);
			swiper.slideTo(swiper.slides.length);

		}.bind(this));

		$(this).on('rowDeleted.swiper', function() {
			this.rebootSwiper(swiper);
		}.bind(this));

		$(this).on('imageLoaded.swiper', function() {
			this.rebootSwiper(swiper);
		}.bind(this));

		$(window).on('resize.swiper', function() {
			this.rebootSwiper(swiper);
		}.bind(this));

	},

	buildSwiper: function() {
		this.swiper = new Swiper (this.querySelector('.swiper-container'), {

			// Optional parameters
			preventClicks: true,
			preventClicksPropagation: true,
			releaseFormElements: false,
			autoplay: this.transition_speed * 1000,

			// Effect
			effect: (this.effect === 'fade' || this.effect === 'slide') ? this.effect : 'slide',
			grabCursor: true,

			// If we need pagination
			pagination: $(this).find('.swiper-pagination')[0],
			paginationClickable: true,

			// Navigation arrows
			nextButton: $(this).find('.swiper-button-next')[0],
			prevButton:  $(this).find('.swiper-button-prev')[0],
			onInit: function(swiper) {
				this._retry_count = 0;
				setTimeout(this._retry.bind(this), this._retry_interval);
				this.initSwiper(swiper);
			}.bind(this)

		});
		this.classList.toggle('multiple-slides', this.stories.length > 1);

	},

	rebootSwiper: function(swiper) {

		swiper.update(true);

	},

	_isAttached: false,
	_swiperReady: false,

	swiper_ready: function() {
		if (this._isAttached) {
			this._loaded = true;
		}

		this._swiperReady = true;
		if (this._deferred) {
			this._deferred = false;
			this.init();
		}
	},

	transition_speedChanged: function(value) {
		if (this.swiper) {
			this.swiper.autoplay = value * 1000;
			this.init();
		}
	},

	categoryChanged: function(value) {
		var split = value.split('-');
		if (this.swiper) {
			this.swiper.slideTo(0);
		}

		if (split[0] === 'top') {
			this._setCategories(null);
			this.set('atavist_library_params.limit', split[1]);
		} else {
			this.set('atavist_library_params.limit', 5);
			this._setCategories(value);
		}
	},

	nine_ways_prefix: 'nine-ways',
	storiesWithSlideStyle: function(stories, slide_style, style) {
		if (slide_style.substr(0, this.nine_ways_prefix.length) === this.nine_ways_prefix) {
			slide_style = this.nine_ways_prefix;
		}

		if (style === slide_style) {
			return stories;
		}
	},

	ready: function() {
		this.minimum = 1;
		if (typeof this.effect === 'undefined') this.effect = 'slide';
		this.addEventListener('dom-change', function() {
			this.debounce('dom-change-init', function() {
				this.init();
			}, 300);
		}.bind(this));
	},

	attached: function() {
		if (!this.category) {
			this.category = 'top-3';
		}

		if (this._swiperReady) {
			this._loaded = true;
		}

		this._isAttached = true;
	}
});
