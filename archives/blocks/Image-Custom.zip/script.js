Polymer({
	properties: {
		the_image: {
			type: Object,
			notify: true
		},
		the_audio: {
			type: Object,
			notify: true,
			observer: 'the_audioChanged'
		},
		the_link: {
			type: String,
			notify: true,
			observer: 'the_linkChanged'
		},
		audio_color_scheme: {
			type: String,
			notify: true,
			value: 'white',
			observer: 'audio_color_schemeChanged'
		},
		the_caption: String,
		is_clickable: Boolean
	},

	/* Observers */

	_checkClickable: function() {
		if ((this.the_link && this.the_link.length > 0) || (this.the_audio && this.the_audio.filename && this.the_audio.filename.length > 0)) {
			this.is_clickable = true;
		} else {
			this.is_clickable = false;
		}
	},

	the_linkChanged: function(value) {
		this._checkClickable();
	},

	/* Stop audio playback if the audio file is removed. */
	the_audioChanged: function(value) {
		var media_audio_annotation = this._audioElement(),
			wrapper;
		if (value && value.filename) {
			if (this.editable()) {
				this.verifyAudioPath(value);
			}

			if (media_audio_annotation) {
				this._setAudio(value);
			} else if (!this._loadingAudio) {
				this._loadingAudio = true;
				this.importHref('/static/bower_components/media-audio-annotation/media-audio-annotation.html', function(e) {
					wrapper = this.querySelector('.atavist-simple-image-wrapper');
					if (wrapper) {
						media_audio_annotation = document.createElement('media-audio-annotation');
						media_audio_annotation.classList.add('media-audio-annotation');
						media_audio_annotation.color = this.audio_color_scheme;
						this.querySelector('.atavist-simple-image-wrapper').appendChild(media_audio_annotation);
						this._setAudio(value);
					}
				}.bind(this));
			}
		} else if ((!value || !value.filename || value.filename === '') && media_audio_annotation) {
			wrapper = this.querySelector('.atavist-simple-image-wrapper');
			if (wrapper) {
				wrapper.removeChild(media_audio_annotation);
				this._loadingAudio = false;
			}
		}

		this._checkClickable();
	},

	audio_color_schemeChanged: function(value) {
		var media_audio_annotation = this._audioElement();
		if (media_audio_annotation) {
			media_audio_annotation.color = value;
		}
	},

	_setAudio: function(value) {
		var media_audio_annotation = this._audioElement();
		if (media_audio_annotation) {
			media_audio_annotation.setAtavistFilename(value.filename);
		}
	},

	_audioElement: function() {
		return this.querySelector('.media-audio-annotation');
	},

	/* Computed values */
	hasAudio: function(value) {
		return (value && value.filename);
	},

	hasLink: function(the_link) {
		return (the_link && the_link.length) ? true : false;
	},

	verifyAudioPath: function(the_audio) {
		var path;
		if (!the_audio || !the_audio.filename) {
			return;
		}

		path = '/data/files/organization/' + this.organizationID() + '/audio/' + the_audio.filename;
		if (!the_audio.path || the_audio.path !== path) {
			the_audio.path = path;
		}
	},

	/* Events */
	_imageClicked: function(e) {
		if ((this.hasLink(this.the_link))) {
			if (this.editable()) {
				$.dismissable('Link clicked: ' + this.the_link);
			} else {
				this._followLink(this.the_link);
			}
		} else if (this.hasAudio(this.the_audio)) {
			var audio_element = this._audioElement();
			if (audio_element) {
				audio_element.toggle();
			}
		}

		e.preventDefault();
		return false;
	},

	_followLink: function(link) {
		var story_controller = document.querySelector('[is=story-controller]');
		if (story_controller) {
			if (story_controller._assessChapterLink(link)) {
				return;
			}
		}

		window.location.href = link;
	},

	/* Lifecycle */
	ready: function() {
		if (this.querySelector('atavist-image').supportsRealSize) {
			this.querySelector('.atavist-simple-image-wrapper').classList.add('atavist-simple-image-wrapper-sized');
		}

		this.querySelector('atavist-image').addEventListener('click', this._imageClicked.bind(this));
	}
});