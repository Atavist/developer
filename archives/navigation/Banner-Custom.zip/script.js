Polymer({
	properties: {
		organization: Object,
		logo: {
			type: Object,
			value: {},
			notify: true
		},
		nav_bar_logo: {
			type: Object,
			value: {},
			notify: true
		},
		banner_background_color: {
			type: String,
			value: '#eeeeee'
		},
		banner_background_image: {
			type: Object,
			value: {},
			notify: true
		},
		banner_background_image_opacity: {
			type: Number,
			value: 25
		},
		banner_height: {
			type: Number,
			value: 400
		},
		footer_text: {
			type: String,
			observer: 'footer_textChanged'
		},
		primary_menu: {
			type: Array,
			reflectToAttribute: true
		}
	},
	behaviors: [
		BoundHTMLBehaviors
	],
	footer_textChanged: function(value) {
		var el = this.querySelector('footer p[data-bound_html]');
		if (el) {
			el.innerHTML = el.dataset.bound_html;
			el.dataset.bound_html = '';
		}
	},

	_bestLogo: function(organization, logo, nav_bar_logo, preferred) {
		var best_logo = null;
		if (preferred === 'nav_bar_logo' && nav_bar_logo) {
			if (typeof nav_bar_logo === 'object' && nav_bar_logo.filename && nav_bar_logo.filename.length) {
				best_logo = this.imagePath(nav_bar_logo.filename);
			} else if (typeof nav_bar_logo === 'string') {
				best_logo = this.imagePath(nav_bar_logo);
			}
		}

		if (!best_logo && logo) {
			if (typeof logo === 'object' && logo.filename && logo.filename.length) {
				best_logo = this.imagePath(logo.filename);
			} else if (typeof logo === 'string') {
				best_logo = this.imagePath(logo);
			}
		}

		// TODO: Why is logo sometimes an object and sometimes a string?
		if (!best_logo) {
			if (organization.logo_for_dark_bg && organization.logo_for_dark_bg.length) {
				best_logo = this.imagePath(organization.logo_for_dark_bg);
			} else if (organization.profile_image && organization.profile_image.length) {
				best_logo = this.imagePath(organization.profile_image);
			}
		}

		return best_logo;
	},

	_logoClass: function(organization, logo, nav_bar_logo, preferred) {
		var classes = [];
		logo = this._bestLogo(organization, logo, nav_bar_logo, preferred);
		if (logo && logo.substring(logo.length - 4) === '.svg') {
			classes.push('needs-width');
		}

		return classes.join(' ');
	},

	_bannerBackground: function(banner_background) {
		if (typeof banner_background === 'object') {
			return this.imagePath(banner_background.filename);
		} else if (typeof banner_background === 'string' && banner_background.length) {
			return this.imagePath(banner_background);
		}

		return null;
	},

	_bannerBackgroundImageStyle: function(banner_background_image, banner_background_image_opacity) {
		var styles = [],
			opacity = (parseInt(banner_background_image_opacity) / 100);

		if (banner_background_image) {
			styles.push('background-image: url(\'' + this._bannerBackground(banner_background_image) + '\')');
		}

		styles.push('opacity: ' + opacity);

		return styles.join('; ');
	},

	_bannerBackgroundStyle: function(organization, banner_background_color, banner_height) {
		var styles = [],
			background_color = this.makeColor(banner_background_color, '000000');

		if (background_color) {
			styles.push('background-color: ' + background_color);
		}

		styles.push('height: ' + banner_height + 'px');
		return styles.join('; ');

	},

	_logoOrText: function(organization, logo, nav_bar_logo, preferred, type) {
		var value;
		if (this._bestLogo(organization, logo, nav_bar_logo, preferred)) {
			value = (type === 'logo') ? true : false;
		} else {
			value = (type === 'logo') ? false : true;
		}

		return value;
	},

	_toggle_mobile_nav: function(e) {
		this.classList.toggle('nav-revealed');
	},

	_init_affix: function(nav) {
		var body = document.querySelector('body'),
			offset = nav.getBoundingClientRect().top - body.getBoundingClientRect().top;
		window.onscroll = function(e) {
			if (body.getBoundingClientRect().top <= (0 - offset)) {
				this.classList.add('affix-nav');
			} else {
				this.classList.remove('affix-nav');
			}
		}.bind(this);
	},

	_heightForLogo: function(banner_height) {
		return banner_height ? 'max-height: ' + (banner_height * 0.75) + 'px' : null;
	},

	ready: function() {
		$(this).on('click', '.nav-menu-button', this._toggle_mobile_nav.bind(this));
		this._init_affix(this.querySelector('nav'));
	},
	extends: 'div'
});