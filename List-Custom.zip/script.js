Polymer({
	properties: {
		featured_layout: {
			type: String,
			value: 'true'
		},
		the_caption: {
			type: String,
			notify: true
		},
		filter: {
			type: String,
			value: 'most-recent-stories',
			observer: 'filtersChanged'
		},
		exclude: {
			type: String,
			value: 'no-exclusions',
			observer: 'filtersChanged'
		},
		display_style: {
			type: String,
			value: function() {
				return 'all';
			}
		}
	},
	behaviors: [
		StoryBlocksBehaviors,
		BoundHTMLBehaviors
	],
	alignments: ['center', 'left', 'right'],
	filtersChanged: function() {
		var categories = [];

		if (this.filter && this.filter !== 'most-recent-stories') {
			categories.push(this.filter);
		}

		if (this.exclude && this.exclude !== 'no-exclusions') {
			categories.push('!' + this.exclude);
		}

		this._setCategories(categories);
	},

	_isFeatured: function(featured_layout, index) {
		return (featured_layout === 'true') ? (index === 0) : false;
	},

	_moreStoriesAfterIndex: function(stories, index) {
		return stories && stories.length > (index + 1);
	},

	_more_stories: function() {
		this._fetch('next');
	},

	_publishedText: function(story) {
		if (parseInt(story.published) === 0) {
			return 'Unpublished Project';
		} else if (story.pub_date_formatted) {
			return story.pub_date_formatted;
		}

		return null;
	},

	_urlForStory: function(story) {
		if (parseInt(story.published) === 0) {
			return 'https://docs.atavist.com/unpublished-projects';
		} else if (story.url) {
			return this._urlForEnvironment(story.url);
		}

		return null;
	},

	_shortExcerptWithEllipsis: function(short_excerpt) {
		if (short_excerpt && short_excerpt.length) {
			return short_excerpt + '... <span class="continue-reading accent-color">Continue Reading</span>';
		}

		return null;
	},

	ready: function() {
		this.set('atavist_library_params.placeholder_limit', 5);
		$(this).on('click', '.load-more-stories', this._more_stories.bind(this));
	}

});
