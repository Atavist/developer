Polymer({
	properties: {
		the_image: {
			type: Object,
			notify: true
		},
		the_link: {
			type: String,
			notify: true,
			observer: 'the_linkChanged'
		},
		the_caption: String,
		is_clickable: Boolean
	},

	/* Observers */

	_checkClickable: function() {
		if ((this.the_link && this.the_link.length > 0)) {
			this.is_clickable = true;
		} else {
			this.is_clickable = false;
		}
	},

	the_linkChanged: function(value) {
		this._checkClickable();
	},

	hasLink: function(the_link) {
		return (the_link && the_link.length) ? true : false;
	},

	/* Events */
	_imageClicked: function(e) {
		if ((this.hasLink(this.the_link))) {
			if (this.editable()) {
				$.dismissable('Link clicked: ' + this.the_link);
			} else {
				this._followLink(this.the_link);
			}
		}

		e.preventDefault();
		return false;
	},

	_followLink: function(link) {
		var story_controller = document.querySelector('[is=story-controller]');
		if (story_controller) {
			if (story_controller._assessChapterLink(link)) {
				return;
			}
		};

		window.location.href = link;
	},

	/* Lifecycle */
	ready: function() {
		if (this.querySelector('atavist-image').supportsRealSize) {
			this.querySelector('.atavist-simple-image-wrapper').classList.add('atavist-simple-image-wrapper-sized');
		};

		this.querySelector('atavist-image').addEventListener('click', this._imageClicked.bind(this));
	}
});